//
//  MyordersTableViewCell.swift
//  PracticeFirebase
//
//  Created by Ramandeep Singh on 2017-07-24.
//  Copyright © 2017 Ramandeep Singh. All rights reserved.
//

import UIKit

class MyordersTableViewCell: UITableViewCell {

    @IBOutlet weak var myorders: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
